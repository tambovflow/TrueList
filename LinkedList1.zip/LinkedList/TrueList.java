public class TrueList{
	private int size;
	private Node root;
	private Node last;

	public void add(int value){
		Node node = new Node(value);
		if(root==null){
			root=last=node;
		}else{
			last.next = node;
			node.previous = last;
			last = node;
		}
		this.size++;
	}

	public void add(int index, int value){
		if(index<0 || index>this.size){
		System.out.println("0.o? Check index!");
		return;
		}
		Node node = new Node(value);
		if(index==0){
			node.next = root;
			root.previous = node;
			root = node;
		}else if(index==this.size){
			node.previous = last;
			last.next = node;
			last = node;
		}else{
			Node rightNode = getNode(index);
			node.previous = rightNode.previous;
			rightNode.previous = node;
			node.next = node.previous.next;
			node.previous.next = node;
		}
		this.size++;
	}

	public int get(int index){
		return getNode(index).value;
	}

	public Node getNode(int index){
		Node element = null;
		if(this.size/2>=index){
			element = root;
			for(int i =0; i<index; i++){
				element = element.next;
			}
		}else{
			element = last;
			for(int i=this.size-1; i>index; i--){
				element = element.previous;
			}
		}
		return element;
	}

	public void remove(int index){
		if(index<0 || index>=this.size){
			System.out.println("oops... I could not find this value");
			return;
		}
		
		if(index==0){
			root = root.next;
			root.previous = null;
		}else if(index==this.size-1){
			last = last.previous;
			last.next = null;
		}else{
			Node removeElement = getNode(index);
			removeElement.next.previous = removeElement.previous;
			removeElement.previous.next = removeElement.next;
		}
		this.size--;
	}

	public void print(){
		StringBuilder string =new StringBuilder("Last Update: ");
			for(int i = 0; i<this.size; i++){
			string.append(get(i)+",");
		}
		string.setLength(string.length()-1);
		System.out.println(string);
	}

	public int size(){
		return this.size;
	}

	private class Node{
		private int value;
		private Node next;
		private Node previous;

		private Node(int value){
			this.value = value;
		}
	}
}