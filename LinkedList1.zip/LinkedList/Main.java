public class Main{
	public static void main(String[] args) {
		TrueList tl = new TrueList();
		//double startTime = System.currentTimeMillis();
		for(int i=0; i<12; i++){
			tl.add(i);
		}

		tl.add(10, 555555);
		tl.print();
		System.out.println("Size: " + tl.size());
		//double endTime = System.currentTimeMillis(); 
		//System.out.println(endTime - startTime);
		tl.remove(12);
		tl.print();
		System.out.println("Size: " + tl.size());
	}
}
